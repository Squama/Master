CREATE VIEW act_id_group AS
  SELECT
    `admin`.`tbl_role`.`id`      AS `ID_`,
    `admin`.`tbl_role`.`version` AS `REV_`,
    `admin`.`tbl_role`.`name`    AS `NAME_`,
    `admin`.`tbl_role`.`code`    AS `TYPE_`
  FROM `admin`.`tbl_role`;
