CREATE VIEW act_id_membership AS
  SELECT
    `admin`.`tbl_user_role`.`userId` AS `USER_ID_`,
    `admin`.`tbl_user_role`.`roleId` AS `GROUP_ID_`
  FROM `admin`.`tbl_user_role`;
